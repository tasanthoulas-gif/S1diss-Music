ΟΔΗΓΙΕΣ ΕΓΚΑΤΑΣΤΑΣΗΣ — Cookie Law Gate
========================================
Ιστοσελίδα: S1DIS LinkFlow
URL: https://s1dis-linkflow.lovable.app

Τι κάνει:
- Μόλις φορτώσει η σελίδα εμφανίζεται ένα πλήρες (full-screen) παράθυρο συγκατάθεσης cookies
  που εμποδίζει τη χρήση της σελίδας μέχρι ο επισκέπτης να διαλέξει.
- «Αποδοχή» -> αποθηκεύεται συναίνεση (cookie + localStorage, 365 ημέρες) και ο επισκέπτης συνεχίζει κανονικά.
- «Απόρριψη» -> ο επισκέπτης ανακατευθύνεται αμέσως εκτός ιστοσελίδας, στο: https://www.google.com

Περιεχόμενα φακέλου:
- cookie-law.js         -> απλό vanilla JS (καμία εξάρτηση) — για ΟΠΟΙΑΔΗΠΟΤΕ ιστοσελίδα (HTML/Vite/Lovable).
- cookie-law.css        -> στυλ του παραθύρου.
- index-snippet.html    -> έτοιμος κώδικας για να επικολλήσεις στο index.html.
- CookieGate.jsx        -> έτοιμο React component (εναλλακτικό της vanilla λύσης), ιδανικό για Lovable / Next.js / Vite React apps.

--------------------------------------------------------------
ΕΠΙΛΟΓΗ Α — Static / Vite / Lovable project (χωρίς React component)
--------------------------------------------------------------
1. Αντέγραψε τα cookie-law.js και cookie-law.css στον φάκελο "public/" του project σου
   (ώστε να σερβίρονται ως /cookie-law.js και /cookie-law.css).
2. Άνοιξε το index.html και πρόσθεσε πριν το </body>:
     <link rel="stylesheet" href="/cookie-law.css" />
     <script src="/cookie-law.js" defer></script>
3. Κάνε deploy. Το banner θα εμφανίζεται σε κάθε φόρτωση μέχρι ο χρήστης να πατήσει Αποδοχή.

Για το https://s1dis-linkflow.lovable.app :
- Στο Lovable editor, πρόσθεσε τα δύο αρχεία στο "public" (Project > Files) και κάνε το
  παραπάνω βήμα 2 στο index.html του project.

--------------------------------------------------------------
ΕΠΙΛΟΓΗ Β — React component (Lovable React app ή Vercel/Next.js app)
--------------------------------------------------------------
1. Αντέγραψε το CookieGate.jsx μέσα στο src/components/ (Vite/Lovable) ή app/components/ (Next.js).
2. Αν είναι Next.js App Router, πρόσθεσε στην ΠΡΩΤΗ γραμμή του αρχείου:  "use client";
3. Εισήγαγε και τοποθέτησέ το ΠΡΩΤΟ μέσα στο ριζικό component:

     import CookieGate from "./components/CookieGate";

     export default function App() {
       return (
         <>
           <CookieGate />
           {/* υπόλοιπη εφαρμογή */}
         </>
       );
     }

Για το https://prod-by-shame.vercel.app/ (Next.js/Vercel):
- Βάλε το CookieGate μέσα στο app/layout.js (ή pages/_app.js αν είναι Pages Router),
  ώστε να εμφανίζεται πριν από ΟΤΙΔΗΠΟΤΕ άλλο περιεχόμενο σε κάθε σελίδα του site.

--------------------------------------------------------------
Παρατηρήσεις
--------------------------------------------------------------
- Η ανακατεύθυνση σε "Απόρριψη" χρησιμοποιεί window.location.replace() ώστε ο χρήστης
  να ΜΗΝ μπορεί να γυρίσει πίσω στη σελίδα με το κουμπί "back" του browser.
- Μπορείς να αλλάξεις το declineUrl σε οποιαδήποτε διεύθυνση θέλεις (π.χ. https://www.google.com).
- Το z-index είναι στο μέγιστο (2147483647) ώστε το banner να καλύπτει τα πάντα.
