// CookieGate.jsx — Πύλη συγκατάθεσης cookies (React / Vite / Lovable / Next.js)
// Χρήση:
//  1) Αντέγραψε αυτό το αρχείο στο src/components/CookieGate.jsx (ή app/components/CookieGate.jsx)
//  2) Εισήγαγέ το και βάλε το ΠΡΩΤΟ μέσα στο βασικό σου component (App.jsx / layout.jsx):
//       import CookieGate from "./components/CookieGate";
//       function App() {
//         return (
//           <>
//             <CookieGate />
//             {/* ...υπόλοιπη εφαρμογή... */}
//           </>
//         );
//       }
//  3) Αν χρησιμοποιείς Next.js App Router, πρόσθεσε στην κορυφή του αρχείου: "use client";

import { useEffect, useState } from "react";

const CONFIG = {
  cookieName: "cookie_consent_s1dis-linkflow",
  cookieDays: 365,
  siteName: `S1DIS LinkFlow`,
  message: `Αυτή η ιστοσελίδα χρησιμοποιεί cookies για να εξασφαλίσει τη σωστή λειτουργία και την καλύτερη εμπειρία περιήγησης. Πατώντας «Αποδοχή» συμφωνείτε με τη χρήση cookies. Πατώντας «Απόρριψη» θα εγκαταλείψετε την ιστοσελίδα.`,
  acceptText: `Αποδοχή`,
  declineText: `Απόρριψη`,
  declineUrl: `https://www.google.com`,
};

function getCookie(name) {
  if (typeof document === "undefined") return null;
  const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return match ? decodeURIComponent(match[2]) : null;
}

function setCookie(name, value, days) {
  const d = new Date();
  d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000);
  document.cookie = `${name}=${encodeURIComponent(value)};expires=${d.toUTCString()};path=/;SameSite=Lax`;
}

export default function CookieGate() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let accepted = getCookie(CONFIG.cookieName) === "accepted";
    try {
      accepted = accepted || window.localStorage.getItem(CONFIG.cookieName) === "accepted";
    } catch (e) {}
    if (!accepted) {
      setVisible(true);
      document.documentElement.style.overflow = "hidden";
    }
  }, []);

  if (!visible) return null;

  const handleAccept = () => {
    setCookie(CONFIG.cookieName, "accepted", CONFIG.cookieDays);
    try {
      window.localStorage.setItem(CONFIG.cookieName, "accepted");
    } catch (e) {}
    document.documentElement.style.overflow = "";
    setVisible(false);
  };

  const handleDecline = () => {
    window.location.replace(CONFIG.declineUrl);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Συγκατάθεση cookies"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 2147483647,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
        background: "rgba(10,12,20,0.72)",
        backdropFilter: "blur(6px)",
        fontFamily:
          '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      }}
    >
      <div
        style={{
          maxWidth: 480,
          width: "100%",
          background: "#fff",
          borderRadius: 18,
          padding: "28px 26px 24px",
          boxShadow: "0 20px 60px rgba(0,0,0,0.35)",
          textAlign: "center",
        }}
      >
        <div
          style={{
            width: 52,
            height: 52,
            margin: "0 auto 14px",
            borderRadius: 14,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "linear-gradient(135deg, #6366f1, #4f46e5)",
            fontSize: 26,
          }}
        >
          🍪
        </div>
        <h2 style={{ margin: "0 0 10px", fontSize: 19, fontWeight: 700, color: "#0f172a" }}>
          {CONFIG.siteName}
        </h2>
        <p style={{ margin: "0 0 22px", fontSize: 14.5, lineHeight: 1.55, color: "#475569" }}>
          {CONFIG.message}
        </p>
        <div style={{ display: "flex", gap: 10 }}>
          <button
            type="button"
            onClick={handleDecline}
            style={{
              flex: 1,
              padding: "12px 14px",
              border: "none",
              borderRadius: 10,
              fontSize: 14.5,
              fontWeight: 600,
              cursor: "pointer",
              background: "#f1f5f9",
              color: "#334155",
            }}
          >
            {CONFIG.declineText}
          </button>
          <button
            type="button"
            onClick={handleAccept}
            style={{
              flex: 1,
              padding: "12px 14px",
              border: "none",
              borderRadius: 10,
              fontSize: 14.5,
              fontWeight: 600,
              cursor: "pointer",
              background: "linear-gradient(135deg, #4f46e5, #4338ca)",
              color: "#fff",
            }}
          >
            {CONFIG.acceptText}
          </button>
        </div>
      </div>
    </div>
  );
}
