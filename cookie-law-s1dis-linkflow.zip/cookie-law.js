/* cookie-law.js — Πύλη συγκατάθεσης cookies για S1DIS LinkFlow
   Αποδοχή -> ο χρήστης συνεχίζει κανονικά στην ιστοσελίδα.
   Απόρριψη -> ο χρήστης ανακατευθύνεται εκτός ιστοσελίδας.
   Επικόλλησε αυτό το αρχείο ως <script> πριν το </body>, μαζί με το cookie-law.css. */
(function () {
  "use strict";

  var CONFIG = {
    cookieName: "cookie_consent_s1dis-linkflow",
    cookieDays: 365,
    siteName: `S1DIS LinkFlow`,
    message: `Αυτή η ιστοσελίδα χρησιμοποιεί cookies για να εξασφαλίσει τη σωστή λειτουργία και την καλύτερη εμπειρία περιήγησης. Πατώντας «Αποδοχή» συμφωνείτε με τη χρήση cookies. Πατώντας «Απόρριψη» θα εγκαταλείψετε την ιστοσελίδα.`,
    acceptText: `Αποδοχή`,
    declineText: `Απόρριψη`,
    declineUrl: `https://www.google.com`
  };

  function getCookie(name) {
    var match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
    return match ? decodeURIComponent(match[2]) : null;
  }

  function setCookie(name, value, days) {
    var d = new Date();
    d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000);
    document.cookie =
      name + "=" + encodeURIComponent(value) + ";expires=" + d.toUTCString() + ";path=/;SameSite=Lax";
  }

  function alreadyAccepted() {
    try {
      return (
        getCookie(CONFIG.cookieName) === "accepted" ||
        window.localStorage.getItem(CONFIG.cookieName) === "accepted"
      );
    } catch (e) {
      return getCookie(CONFIG.cookieName) === "accepted";
    }
  }

  function persistAccept() {
    setCookie(CONFIG.cookieName, "accepted", CONFIG.cookieDays);
    try {
      window.localStorage.setItem(CONFIG.cookieName, "accepted");
    } catch (e) {}
  }

  function showBanner() {
    if (alreadyAccepted()) return;

    document.documentElement.style.overflow = "hidden";

    var overlay = document.createElement("div");
    overlay.id = "cookie-law-overlay";
    overlay.innerHTML =
      '<div class="cookie-law-box" role="dialog" aria-modal="true" aria-label="Συγκατάθεση cookies">' +
      '<div class="cookie-law-icon">🍪</div>' +
      "<h2>" + CONFIG.siteName + "</h2>" +
      "<p>" + CONFIG.message + "</p>" +
      '<div class="cookie-law-actions">' +
      '<button type="button" id="cookie-law-decline">' + CONFIG.declineText + "</button>" +
      '<button type="button" id="cookie-law-accept">' + CONFIG.acceptText + "</button>" +
      "</div>" +
      '<div class="cookie-law-note">Πατώντας «' + CONFIG.acceptText + '» αποδέχεστε τη χρήση cookies. Πατώντας «' + CONFIG.declineText + '» θα εγκαταλείψετε την ιστοσελίδα.</div>' +
      "</div>";

    document.body.appendChild(overlay);

    document.getElementById("cookie-law-accept").addEventListener("click", function () {
      persistAccept();
      overlay.parentNode && overlay.parentNode.removeChild(overlay);
      document.documentElement.style.overflow = "";
    });

    document.getElementById("cookie-law-decline").addEventListener("click", function () {
      window.location.replace(CONFIG.declineUrl);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", showBanner);
  } else {
    showBanner();
  }
})();
